<?php
#################################################################
## MyPHPAuction 2009															##
##-------------------------------------------------------------##
## Copyright �2009 MyPHPAuction. All rights reserved.	##
##-------------------------------------------------------------##
#################################################################

if ( !defined('INCLUDED') ) { die("Access Denied"); }
?>
<?php echo $members_area_header;?>
<br>
<?php echo $fee_payment_header;?>
<br>
<?php echo $payment_table_display;?>