<?php
/* Database Host Name */
$db_host = 'localhost';
/* Database Username */
$db_username = 'adamo_store';
/* Database Login Password */
$db_password = 'adamo';
/* Database Name */
$db_name = 'adamo_store';
/* Database and Session prefixes */
define('DB_PREFIX', 'myphpauction_'); ## Do not edit !
define('SESSION_PREFIX', 'myphpauction_');
?>