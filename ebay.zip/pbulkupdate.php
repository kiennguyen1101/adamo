<?php
$buildversion     = "1.02";
$download_path    = "http://localhost/myphpauctionv6/bulk.zip";

?>