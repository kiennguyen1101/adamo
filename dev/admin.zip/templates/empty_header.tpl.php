﻿<?php
#################################################################
## MyPHPAuction 2009															##
##-------------------------------------------------------------##
## Copyright ©2009 MyPHPAuction. All rights reserved.	##
##-------------------------------------------------------------##
#################################################################

  if (!defined('INCLUDED')) {
    die("Access Denied");
  }
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <title>
      <?php echo $setts['sitename']; ?>
    </title>
    <meta http-equiv="Content-Type" content="text/html; charset=<?php echo LANG_CODEPAGE; ?>">
    <link href="themes/<?php echo $setts['default_theme']; ?>/style.css" rel="stylesheet" type="text/css">
    <style type="text/css">
      <!--
      .style1 {
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 10px;
      }
      -->
    </style>
  </head>
  <body>