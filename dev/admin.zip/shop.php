<?php
#################################################################
## MyPHPAuction v6.05															##
##-------------------------------------------------------------##
## Copyright �2009 MyPHPAuction. All rights reserved.	##
##-------------------------------------------------------------##
#################################################################

session_start();

define ('IN_SITE', 1);

include_once ('includes/global.php');
include_once ('includes/class_shop.php');
include_once ('includes/functions_item.php');

if ($setts['enable_stores'])
{
	include_once ('global_header.php');
	
	$user_id = intval($_REQUEST['user_id']);
	$parent_id = intval($_REQUEST['parent_id']);
	$keywords_search = $db->rem_special_chars($_REQUEST['keywords_search']);
	
	$is_store = false;
	
	if ($user_id)
	{
		$template->set('user_id', $user_id);
		$template->set('parent_id', $parent_id);
		$template->set('keywords_search', $keywords_search);
		
		$shop = new shop();
		$shop->setts = &$setts;
		$shop->user_id = $user_id;
		
		$user_details = $db->get_sql_row("SELECT * FROM	" . DB_PREFIX . "users WHERE user_id=" . $user_id);
		
		$shop_status = $shop->shop_status($user_details);
		
		if ($shop_status['enabled'])
		{
			if ($session->value('user_id'))
			{
				$is_favorite_store = $db->count_rows('favourite_stores', "WHERE store_id='" . $user_details['user_id'] . "' AND user_id='" . $session->value('user_id') . "'");
			
				if ($_GET['option'] == 'favorites')
				{
					if (!$is_favorite_store)
					{
						$db->query("INSERT INTO " . DB_PREFIX . "favourite_stores 
							(store_id, user_id) VALUES 
							('" . $user_id . "', '" . $session->value('user_id') . "')");
						
						$is_favorite_store = 1;
					}
					else 
					{
						$db->query("DELETE FROM " . DB_PREFIX . "favourite_stores WHERE 
							store_id='" . $user_id . "' AND user_id='" . $session->value('user_id') . "'");
						
						$is_favorite_store = 0;
					}
				}

				$favorite_store = '[ <a href="shop.php?option=favorites&user_id=' . $user_id . '">' . ((!$is_favorite_store) ? MSG_ADD_TO_FAVORITES : MSG_REMOVE_FROM_FAVORITES) . '</a> ]';
			}
	
			(array) $query = null;
			define('IS_SHOP', 1);
			$shop_pages = array('shop_about', 'shop_specials', 'shop_shipping_info', 'shop_company_policies');
			
			$template->set('page', $_REQUEST['page']);
			
			$is_store = true;
	
			$shop_header_msg = GMSG_STORE . ' - ' . $user_details['shop_name'] . ' ' . $favorite_store;
			$template->set('shop_header_msg', $shop_header_msg);
			
			(string) $shop_header = null;
			(string) $shop_footer = null;
			
			$shop_header = '<link href="store_templates/store' . $user_details['shop_template_id'] . '/store_style.css" rel="stylesheet" type="text/css"> ';
			
			//$template->set('db', $db);
			//$template->set('fees', $fees);
			$template->set('user_details', $user_details);
	
			if (!in_array($_REQUEST['page'], $shop_pages))## MyPHPAuction 2009 header details (for the shop listings page)
			{
				(string) $shop_subcategories_content = null;
	
				$shop_categories_header = category_navigator($parent_id, true, true, 'shop.php', 'user_id=' . $user_id . '&keywords_search=' . $keywords_search);
				$template->set('shop_categories_header', $shop_categories_header);
	
				$is_subcategories = $db->count_rows('categories', "WHERE parent_id='" . $parent_id . "'");
				$template->set('is_subcategories', $is_subcategories);
				
				if (!empty($user_details['shop_categories']) && !$parent_id) 
				{
					$shop_categories = last_char($user_details['shop_categories']);
					
					$categories_query = " AND category_id IN (" . $shop_categories . ")";
				}
						  
				$sql_select_categories = $db->query("SELECT category_id FROM " . DB_PREFIX . "categories WHERE 
					parent_id='" . $parent_id . "' AND (user_id=0 OR user_id='" . $user_details['user_id'] . "') 
					" . $categories_query . " ORDER BY order_id ASC, name ASC");
	
				while ($cat_details = $db->fetch_array($sql_select_categories)) 
				{
					$background = ($counter++%2) ? 'c2_shop' : 'c3_shop';
	
					$shop_subcategories_content .= '<tr class="' . $background . '"> '.
						'	<td width="100%">&nbsp;&raquo;&nbsp;<a href="shop.php?parent_id=' . $cat_details['category_id'] . '&user_id=' . $user_id . '">' . $category_lang[$cat_details['category_id']] . '</a></td> '.
						'</tr> ';
				}
				
				$template->set('shop_subcategories_content', $shop_subcategories_content);
	
	
				/**
				 * featured items, recently listed and ending soon code
				 */
				if ($user_details['shop_nb_feat_items'])
				{
					(array) $feat_item_details = null;
					
					$select_condition = "WHERE	active=1 AND approved=1 AND closed=0 AND deleted=0 
						AND list_in!='auction' AND owner_id='" . $user_id . "' AND creation_in_progress=0"; 
				
					$feat_item_details = $db->random_rows('auctions', 'auction_id, name, start_price, max_bid, currency, end_time', $select_condition, $user_details['shop_nb_feat_items']);
					$template->set('feat_item_details', $feat_item_details);
				}
				
				if ($user_details['shop_nb_ending_items'] && !$parent_id)
				{				
					$sql_select_ending_items = $db->query("SELECT * FROM " . DB_PREFIX . "auctions 
						FORCE INDEX (auctions_end_time) WHERE 
						active=1 AND approved=1 AND closed=0 AND deleted=0 
						AND list_in!='auction' AND owner_id='" . $user_id . "' AND creation_in_progress=0 
						ORDER BY end_time ASC LIMIT " . $user_details['shop_nb_ending_items']);
					
					(string) $shop_ending_auctions_content = null;
					
					while ($item_details = $db->fetch_array($sql_select_ending_items)) 
					{ 
						$background = ($counter++%2) ? 'c2_shop' : 'c3_shop';
						
						$shop_ending_auctions_content .= '<tr height="15" class="'. $background .'"> '.
							'	<td width="11"><img src="themes/' . $setts['default_theme'] . '/img/arr_it.gif" width="11" height="11" hspace="4"></td> '.
							'	<td width="100%" class="contentfont_shop"><a href="' . process_link('auction_details', array('name' => $item_details['name'], 'auction_id' => $item_details['auction_id'])).'">' . title_resize($item_details['name']).'</a><br> '.
							'		<div class="smallfont_shop"><b>' . MSG_TIME_LEFT . '</b>: '. time_left($item_details['end_time']) . '</div> '.
							'		<div class="smallfont_shop"><b>' . MSG_CURRENTLY . '</b>: ' . $fees->display_amount((($item_details['max_bid']>0) ? $item_details['max_bid'] : $item_details['start_price']), $item_details['currency']) . '</div></td> '.
							'	<td nowrap>' . item_pics($item_details) . '</td> '.
							'</tr> ';
					}
					
					$template->set('shop_ending_auctions_content', $shop_ending_auctions_content);
				}
	
				if ($user_details['shop_nb_recent_items'] && !$parent_id)
				{
					$sql_select_recent_items = $db->query("SELECT * FROM " . DB_PREFIX . "auctions 
						FORCE INDEX (auctions_end_time) WHERE 						
						active=1 AND approved=1 AND closed=0 AND deleted=0 AND creation_in_progress=0  
						AND list_in!='auction' AND owner_id='" . $user_id . "' 
						ORDER BY start_time DESC LIMIT " . $user_details['shop_nb_recent_items']);
					
					(string) $shop_recent_auctions_content = null;
					
					while ($item_details = $db->fetch_array($sql_select_recent_items)) 
					{ 
						$background = ($counter++%2) ? 'c2_shop' : 'c3_shop';
						
						$shop_recent_auctions_content .= '<tr height="15" class="'. $background .'"> '.
							'	<td width="11"><img src="themes/' . $setts['default_theme'] . '/img/arr_it.gif" width="11" height="11" hspace="4"></td> '.
							'	<td width="100%" class="contentfont_shop"><a href="' . process_link('auction_details', array('name' => $item_details['name'], 'auction_id' => $item_details['auction_id'])).'">' . title_resize($item_details['name']).'</a><br> '.
							'		<div class="smallfont_shop"><b>' . MSG_TIME_LEFT . '</b>: '. time_left($item_details['end_time']) . '</div> '.
							'		<div class="smallfont_shop"><b>' . MSG_CURRENTLY . '</b>: ' . $fees->display_amount((($item_details['max_bid']>0) ? $item_details['max_bid'] : $item_details['start_price']), $item_details['currency']) . '</div></td> '.
							'	<td nowrap>' . item_pics($item_details) . '</td> '.
							'</tr> ';
					}
					
					$template->set('shop_recent_auctions_content', $shop_recent_auctions_content);
				}
			}
			
			$shop_footer = $template->process('shop_footer.tpl.php');
			
			$template->change_path('store_templates/store' . $user_details['shop_template_id'] . '/');
			$shop_header .= $template->process('header.php');
			$shop_footer .= $template->process('footer.php');
			
			$template->change_path('templates/');
			$shop_header .= $template->process('shop_header.tpl.php');
			
			if (in_array($_REQUEST['page'], $shop_pages))
			{
				$template->set('message_header', $header_browse_auctions);
				$template->set('message_content', $shop_header . '<p>' . $db->add_special_chars($user_details[$_REQUEST['page']]) . '</p>' . $shop_footer);
			
				$template_output .= $template->process('single_message.tpl.php');				
			}
			else 
			{
				/**
				 * below we have the variables that need to be declared in each separate browse page
				 */
				$page_url = 'shop';			
				
				if ($keywords_search)
				{
					$keywords_search = optimize_search_string($keywords_search);

					$query[] = "MATCH (a.name, a.description) AGAINST ('+" . $keywords_search . "' IN BOOLEAN MODE)";	
				}
				
				if ($parent_id)
				{
					(array) $src_cats = null;
					(string) $category_name = null;
					reset($categories_array);
					
					foreach ($categories_array as $key => $value)
					{
						if ($parent_id == $key)
						{
							
							list($category_name, $tmp_user_id) = $value;
						}
					}
					
					reset($categories_array);
	
					
					while (list($cat_array_id, $cat_array_details) = each($categories_array)) 
					{
						list($cat_array_name, $cat_user_id) = $cat_array_details;
						
						$categories_match = strpos($cat_array_name, $category_name);
						if (trim($categories_match) == "0") 
						{
							$src_cats[] = $cat_array_id;
						}
	
						$all_subcategories = $db->implode_array($src_cats);
					}
	
					$query[] = "(a.category_id IN (" . $all_subcategories . ") OR a.addl_category_id IN (" . $all_subcategories . "))";
				}
	         
				$addl_where_query = $db->implode_array($query, ' AND ');
				$addl_where_query = (!empty($addl_where_query)) ? ' AND ' . $addl_where_query : '';
				
				$where_query = "WHERE a.active=1 AND a.approved=1 AND a.closed=0 AND a.deleted=0 AND a.list_in!='auction' AND 
					a.owner_id='" . $user_id . "' AND a.creation_in_progress=0 " . $addl_where_query;
				
				$order_field = (in_array($_REQUEST['order_field'], $auction_ordering)) ? $_REQUEST['order_field'] : 'a.end_time'; 
				$order_type = (in_array($_REQUEST['order_type'], $order_types)) ? $_REQUEST['order_type'] : 'ASC';
				
				$additional_vars = '&user_id=' . $user_id . '&parent_id=' . $parent_id . '&keywords_search=' . $keywords_search;
				
				$template->set('shop_header', $shop_header);
				$template->set('shop_footer', $shop_footer);
				
				include_once('includes/page_browse_auctions.php');
			}
		}
	}
	
	if (!$is_store)
	{
		$template->set('message_header', header5(MSG_STORE_ERROR_TITLE));
		$template->set('message_content', '<p align="center">' . MSG_STORE_ERROR_CONTENT . '</p>');
	
		$template_output .= $template->process('single_message.tpl.php');	
	}
	
	include_once ('global_footer.php');
	
	echo $template_output;
}
else 
{
	header_redirect('index.php');
}
?>