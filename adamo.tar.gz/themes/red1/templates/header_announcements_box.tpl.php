<?php
#################################################################
## myphpauction V6.8															##
##-------------------------------------------------------------##
## Copyright �2008 myphpauction SoftwareLTD. All rights reserved.	##
##-------------------------------------------------------------##
#################################################################

if ( !defined('INCLUDED') ) { die("Access Denied"); }
?>

<table border="0" cellpadding="3" cellspacing="3" width="100%" class="c1 border contentfont">
	<?php echo $announcement_content;?>
</table>
