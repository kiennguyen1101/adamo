<?php

  /*
   * To change this template, choose Tools | Templates
   * and open the template in the editor.
   */

  /**
   * Description of class_payment
   *
   * @author Kien
   */
  class payment extends fees {

    public function __construct() {
      parent::fees();
    }

    public function callback_process($param) {
      
    }

  }

?>
