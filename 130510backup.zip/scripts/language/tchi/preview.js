function loadTxt()
    {
    document.getElementById("btnClose").value = "\u95dc\u9589 ";
    }
function writeTitle()
    {
    document.write("<title>\u9810\u89bd </title>")
    }