function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "\u540d\u7a31 ";
    document.getElementById("btnCancel").value = "\u53d6\u6d88 ";
    document.getElementById("btnInsert").value = "\u63d2\u5165 ";
    document.getElementById("btnApply").value = "\u61c9\u7528 ";
    document.getElementById("btnOk").value = " \u78ba\u5b9a  ";
    }
function writeTitle()
    {
    document.write("<title>\u66f8\u61fa </title>")
    }