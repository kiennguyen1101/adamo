function loadTxt()
    {
    document.getElementById("btnClose").value = "\u5173\u95ed ";
    }
function writeTitle()
    {
    document.write("<title>\u9884\u89c8 </title>")
    }
