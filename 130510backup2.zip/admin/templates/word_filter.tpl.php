<?php
#################################################################
## MyPHPAuction v6.04															##
##-------------------------------------------------------------##
## Copyright �2009 MyPHPAuction. All rights reserved.	##
##-------------------------------------------------------------##
#################################################################

if ( !defined('INCLUDED') ) { die("Access Denied"); }
?>

<div class="mainhead"><img src="images/tools.gif" align="absmiddle"> <?php echo $header_section;?></div>
<?php echo $msg_changes_saved;?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
   <tr>
      <td width="4"><img src="images/c1.gif" width="4" height="4"></td>
      <td width="100%" class="ftop"><img src="images/pixel.gif" width="1" height="1"></td>
      <td width="4"><img src="images/c2.gif" width="4" height="4"></td>
   </tr>
</table>
<table width="100%" border="0" cellpadding="3" cellspacing="3" class="fside">
   <form action="word_filter.php" method="post">
      <tr>
         <td class="c3"><img src="images/subt.gif" align="absmiddle" hspace="4" vspace="2"> <b><?php echo strtoupper($subpage_title);?></b></td>
      </tr>
      <tr valign="top">
         <td align="center"><table width="100%" border="0" cellpadding="3" cellspacing="3" class="border">
               <tr class="c4">
                  <td width="20">&nbsp;</td>
                  <td><b><?php echo AMSG_WORD;?></b></td>
                  <td width="80" align="center"><b><?php echo AMSG_DELETE;?></b></td>
               </tr>
               <?php echo $word_filter_page_content;?>
            </table></td>
      </tr>
      <tr>
         <td class="c4"><img src="images/subt.gif" align="absmiddle" hspace="4" vspace="2"> <?php echo AMSG_ADD_WORD;?></td>
      </tr>
      <tr>
         <td><table width="100%" border="0" cellpadding="3" cellspacing="3" class="border">
            <tr class="c2">
               <td width="20">&nbsp;</td>
               <td><input type="text" name="new_word" size="50" /></td>
               <td width="80" align="center">&nbsp;</td>
            </tr>
         </table></td>
      </tr>
      <tr>
         <td align="center"><input type="submit" name="form_save_settings" value="<?php echo AMSG_SAVE_CHANGES;?>"></td>
      </tr>
   </form>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
   <tr>
      <td width="4"><img src="images/c3.gif" width="4" height="4"></td>
      <td width="100%" class="fbottom"><img src="images/pixel.gif" width="1" height="1"></td>
      <td width="4"><img src="images/c4.gif" width="4" height="4"></td>
   </tr>
</table>