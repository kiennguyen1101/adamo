<?php
#################################################################
## MyPHPAuction 2009															##
##-------------------------------------------------------------##
## Copyright �2009 MyPHPAuction. All rights reserved.	##
##-------------------------------------------------------------##
#################################################################

define ('MSG_ERROR_MYSQL_CONNECT', 'Could not connect to the database with the credentials you have submitted');
define ('MSG_MYSQL_ERROR_OCCURRED', 'A Mysql error has occurred while running the script: ');
define ('MSG_SQL_ERROR', 'Mysql Error Output');
define ('MSG_SQL_QUERY', 'SQL Query');
define ('MSG_ERROR_MYSQL_SELECT_DB', 'Could not select the database you have submitted');
define ('MSG_ERROR_MYSQL_NUM_ROWS', 'Could not count the rows resulted from your query');
define ('MSG_ERROR_MYSQL_QUERY', 'The query you are trying to run is invalid');
define ('MSG_ERROR_MYSQL_FETCH_ARRAY', 'The fetch array operation has failed.');
define ('MSG_ERROR_MYSQL_RESULT', 'Invalid result set');

?>