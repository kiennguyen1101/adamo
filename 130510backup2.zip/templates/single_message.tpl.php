﻿<?php
#################################################################
## MyPHPAuction 2009															##
##-------------------------------------------------------------##
## Copyright ©2009 MyPHPAuction. All rights reserved.	##
##-------------------------------------------------------------##
#################################################################

  if (!defined('INCLUDED')) {
    die("Access Denied");
  }
?>
<?php echo $custom_header; ?>
<?php echo $message_header; ?>
<?php echo $message_content; ?>
<?php echo $custom_footer; ?>
